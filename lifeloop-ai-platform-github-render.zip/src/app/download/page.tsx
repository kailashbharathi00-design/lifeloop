import { stat } from "node:fs/promises";
import path from "node:path";
import Link from "next/link";
import { SectionLabel } from "@/components/ui";

export const dynamic = "force-dynamic";

const ZIP_PATH = path.join(
  process.cwd(),
  "public",
  "downloads",
  "lifeloop-ai-web-and-mobile.zip",
);

export default async function DownloadPage() {
  let sizeKb = 0;
  try {
    const info = await stat(ZIP_PATH);
    sizeKb = Math.max(1, Math.round(info.size / 1024));
  } catch {
    sizeKb = 0;
  }

  return (
    <div className="mx-auto max-w-[980px] px-4 py-10 sm:px-6 sm:py-14">
      <SectionLabel>Source code bundle</SectionLabel>
      <h1 className="display mt-3 text-[34px] sm:text-[46px]">
        Download both applications <span className="accent-serif text-forest">in one ZIP.</span>
      </h1>
      <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-ink/60">
        Includes the fullstack Next.js web application &amp; shared AI backend plus the companion
        Flutter mobile application, ready to run locally.
      </p>

      <div className="mt-7 overflow-hidden rounded-[24px] border border-moss/20 bg-moss p-6 text-paper sm:p-8">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-lime">
              lifeloop-ai-web-and-mobile.zip {sizeKb > 0 ? `· ${sizeKb} KB` : ""}
            </p>
            <h2 className="display mt-2 text-[24px] sm:text-[28px]">
              Web (Next.js) + Mobile (Flutter)
            </h2>
            <p className="mt-2 max-w-md text-[12.5px] leading-relaxed text-paper/65">
              Excludes <code className="text-lime">node_modules</code> and build caches so the
              archive stays lightweight and clean.
            </p>
          </div>
          <a
            href="/api/download"
            download="lifeloop-ai-web-and-mobile.zip"
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-lime px-6 py-3.5 text-[14px] font-bold text-moss transition hover:bg-lime-soft"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2.2} aria-hidden>
              <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Download ZIP
          </a>
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="rounded-[22px] border border-line bg-paper p-5">
          <p className="mono-label">01 · web-nextjs/</p>
          <h3 className="mt-2 text-[17px] font-semibold">Next.js Web App &amp; AI Backend</h3>
          <ul className="mt-3 space-y-1.5 text-[12.5px] text-ink/65">
            <li>• Landing page, Dashboard, Report Wizard, Heatmap, Impact &amp; Thread pages</li>
            <li>• AI engine: vision + multilingual text classification, priority &amp; duplicates</li>
            <li>• Drizzle ORM PostgreSQL schema, seed data &amp; shared JSON REST API</li>
          </ul>
          <pre className="mt-4 overflow-x-auto rounded-xl bg-bone p-3 font-mono text-[11px] text-ink/80">
{`cd web-nextjs
cp .env.example .env
npm install
npx drizzle-kit push
npm run dev`}
          </pre>
        </div>

        <div className="rounded-[22px] border border-line bg-paper p-5">
          <p className="mono-label">02 · mobile-flutter/</p>
          <h3 className="mt-2 text-[17px] font-semibold">Flutter Mobile Application</h3>
          <ul className="mt-3 space-y-1.5 text-[12.5px] text-ink/65">
            <li>• Material 3 mobile UI matching the LifeLoop AI civic theme</li>
            <li>• Dashboard, AI Report Wizard with camera/gallery, Detail, Heatmap &amp; Impact</li>
            <li>• Connects directly to the shared Next.js backend REST endpoints</li>
          </ul>
          <pre className="mt-4 overflow-x-auto rounded-xl bg-bone p-3 font-mono text-[11px] text-ink/80">
{`cd mobile-flutter
flutter create . --platforms=android,ios
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000`}
          </pre>
        </div>
      </div>

      <div className="mt-6 flex items-center justify-between rounded-2xl border border-line bg-paper px-4 py-3 text-[12px]">
        <span className="text-ink/55">Direct file link: <code className="text-forest">/api/download</code></span>
        <Link href="/dashboard" className="font-semibold text-forest hover:underline">
          Back to dashboard →
        </Link>
      </div>
    </div>
  );
}
