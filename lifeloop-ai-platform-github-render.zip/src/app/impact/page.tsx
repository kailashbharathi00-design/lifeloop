import Link from "next/link";
import { Avatar, CategoryGlyph, SectionLabel, Stat } from "@/components/ui";
import { getAllReports, getLeaderboard, getPlatformStats } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";
import { categoryMeta } from "@/lib/types";

export const dynamic = "force-dynamic";

function badgeFor(points: number): { label: string; className: string } {
  if (points >= 400) return { label: "Loop legend", className: "bg-moss text-lime" };
  if (points >= 300) return { label: "Anchor", className: "bg-forest text-paper" };
  if (points >= 200) return { label: "Change maker", className: "bg-lime-soft text-forest" };
  if (points >= 100) return { label: "Active citizen", className: "bg-mist text-ink/70" };
  return { label: "New neighbour", className: "bg-bone text-ink/50" };
}

const POINT_RULES = [
  { action: "Publish a report with evidence", points: "+10", who: "Reporter" },
  { action: "Confirm you can see the issue too", points: "+4", who: "Verifier" },
  { action: "Your report gets a neighbour confirmation", points: "+2", who: "Reporter" },
  { action: "Correct an AI category or priority", points: "+5", who: "Reviewer" },
  { action: "Post a useful action update", points: "+3", who: "Contributor" },
  { action: "Advance a report to in progress", points: "+6", who: "Contributor" },
  { action: "Issue is resolved and verified", points: "+25", who: "Reporter" },
];

export default async function ImpactPage() {
  await ensureSeeded();
  const [allReports, leaders, current] = await Promise.all([
    getAllReports(),
    getLeaderboard(),
    getCurrentUser(),
  ]);
  const stats = await getPlatformStats(allReports, leaders);
  const me = leaders.find((leader) => leader.id === current.id) ?? current;
  const myRank = leaders.findIndex((leader) => leader.id === current.id) + 1;

  const chartWidth = 760;
  const chartHeight = 150;
  const peak = Math.max(1, ...stats.trend.map((day) => Math.max(day.reported, day.resolved)));
  const buildPath = (key: "reported" | "resolved") =>
    stats.trend
      .map((day, index) => {
        const x = (index / Math.max(1, stats.trend.length - 1)) * chartWidth;
        const y = chartHeight - (day[key] / peak) * (chartHeight - 16) - 8;
        return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");

  const reportedPath = buildPath("reported");
  const resolvedPath = buildPath("resolved");

  const topThree = leaders.slice(0, 3);
  const bestCategory = [...stats.byCategory].sort((a, b) => b.resolved - a.resolved)[0];
  const resolvedThisWeek = stats.trend.slice(-7).reduce((sum, day) => sum + day.resolved, 0);

  return (
    <div className="mx-auto max-w-[1180px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <SectionLabel>Green impact points</SectionLabel>
          <h1 className="display mt-3 max-w-2xl text-[34px] leading-[1.03] sm:text-[44px]">
            Small actions, <span className="accent-serif text-forest">measurable momentum.</span>
          </h1>
          <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-ink/60">
            Every verified report, confirmation and correction earns impact points. Points reward
            useful evidence and follow-through — never duplicate filing.
          </p>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border border-line bg-paper px-4 py-3">
          <Avatar name={me.name} tone={me.tone} size="lg" />
          <div>
            <p className="mono-label">Your impact</p>
            <p className="mt-0.5 text-[15px] font-semibold">{me.points} points</p>
            <p className="text-[10.5px] text-ink/45">
              Rank #{myRank || "—"} · {me.neighbourhood}
            </p>
          </div>
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat value={stats.impactPoints.toLocaleString()} label="Total impact points" hint="all contributors" tone="dark" />
        <Stat value={stats.resolved} label="Resolved issues" hint={`${resolvedThisWeek} in the last 7 days`} tone="lime" />
        <Stat value={stats.neighbours} label="Active neighbours" hint="reporting and verifying" />
        <Stat value={`${stats.avgResolutionHours}h`} label="Avg. resolution time" hint="reported → verified resolved" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="rounded-[24px] border border-line bg-paper p-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="mono-label">Podium</p>
              <h2 className="display mt-1 text-[22px]">Top contributors</h2>
            </div>
            <Link href="/dashboard" className="text-[11px] font-semibold text-forest hover:underline">
              All reports →
            </Link>
          </div>
          <div className="mt-4 space-y-2">
            {topThree.map((leader, index) => {
              const badge = badgeFor(leader.points);
              return (
                <div
                  key={leader.id}
                  className={`flex items-center gap-3 rounded-2xl border p-3 ${
                    index === 0 ? "border-forest/30 bg-lime-soft/50" : "border-line bg-bone/40"
                  }`}
                >
                  <span
                    className={`flex h-7 w-7 items-center justify-center rounded-full font-mono text-[11px] font-semibold ${
                      index === 0 ? "bg-moss text-lime" : "bg-paper text-ink/50"
                    }`}
                  >
                    {index + 1}
                  </span>
                  <Avatar name={leader.name} tone={leader.tone} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold">{leader.name}</p>
                    <p className="text-[10.5px] text-ink/45">
                      {leader.neighbourhood} · {leader.reportsCount} reports · {leader.resolvedCount} resolved
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-[12px] font-semibold text-forest">{leader.points}</p>
                    <span className={`inline-block rounded-full px-1.5 py-0.5 text-[8.5px] font-semibold uppercase tracking-[0.08em] ${badge.className}`}>
                      {badge.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 rounded-xl border border-line bg-bone/50 p-3">
            <p className="mono-label">Recognition tiers</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {[
                { points: 100, label: "Active citizen" },
                { points: 200, label: "Change maker" },
                { points: 300, label: "Anchor" },
                { points: 400, label: "Loop legend" },
              ].map((tier) => (
                <span key={tier.label} className="rounded-full border border-line bg-paper px-2 py-1 text-[9.5px] text-ink/55">
                  {tier.points}+ · {tier.label}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-[24px] border border-line bg-paper p-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="mono-label">14-day activity</p>
              <h2 className="display mt-1 text-[22px]">Reports in, fixes out</h2>
            </div>
            <div className="flex items-center gap-3 text-[10px] text-ink/45">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-4 rounded-full bg-forest" /> reported
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-4 rounded-full bg-lime" /> resolved
              </span>
            </div>
          </div>
          <div className="mt-4 overflow-hidden">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="h-[150px] w-full" role="img" aria-label="Reports and resolutions over 14 days">
              {[0.25, 0.5, 0.75].map((fraction) => (
                <line
                  key={fraction}
                  x1="0"
                  x2={chartWidth}
                  y1={chartHeight * fraction}
                  y2={chartHeight * fraction}
                  stroke="#e2e2d5"
                  strokeWidth="1"
                />
              ))}
              <path d={`${reportedPath} L${chartWidth},${chartHeight} L0,${chartHeight} Z`} fill="#146349" opacity="0.09" />
              <path d={reportedPath} fill="none" stroke="#146349" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
              <path d={resolvedPath} fill="none" stroke="#b3d94a" strokeWidth="2.4" strokeDasharray="5 4" strokeLinejoin="round" />
            </svg>
            <div className="mt-1 flex justify-between font-mono text-[8.5px] uppercase tracking-[0.1em] text-ink/35">
              <span>{stats.trend[0]?.date.slice(5)}</span>
              <span>{stats.trend[Math.floor(stats.trend.length / 2)]?.date.slice(5)}</span>
              <span>today</span>
            </div>
          </div>

          <div className="mt-4 space-y-2.5">
            <p className="mono-label">Resolution by category</p>
            {stats.byCategory.map((item) => {
              const meta = categoryMeta(item.category);
              const pct = item.count ? Math.round((item.resolved / item.count) * 100) : 0;
              return (
                <div key={item.category} className="flex items-center gap-2.5">
                  <span className="flex w-[104px] shrink-0 items-center gap-1.5 text-[10.5px] text-ink/60">
                    <CategoryGlyph category={item.category} className="h-3 w-3" />
                    {meta.short}
                  </span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                    <div className="h-full rounded-full bg-forest/80" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-14 text-right font-mono text-[9.5px] text-ink/45">
                    {item.resolved}/{item.count}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.25fr_0.75fr]">
        <div className="overflow-hidden rounded-[24px] border border-line bg-paper">
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <p className="mono-label">Full leaderboard</p>
            <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-ink/35">
              points · reports · resolved
            </span>
          </div>
          <div className="divide-y divide-line">
            {leaders.map((leader, index) => {
              const badge = badgeFor(leader.points);
              const isMe = leader.id === current.id;
              return (
                <div
                  key={leader.id}
                  className={`flex items-center gap-3 px-5 py-3 ${isMe ? "bg-lime-soft/40" : ""}`}
                >
                  <span className="w-5 font-mono text-[11px] text-ink/35">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <Avatar name={leader.name} tone={leader.tone} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-semibold">
                      {leader.name}
                      {isMe && <span className="ml-1.5 text-[9px] font-medium text-forest">you</span>}
                    </p>
                    <p className="text-[10px] text-ink/45">
                      {leader.neighbourhood} · {leader.role}
                    </p>
                  </div>
                  <span className={`hidden rounded-full px-2 py-0.5 text-[8.5px] font-semibold uppercase tracking-[0.08em] sm:inline ${badge.className}`}>
                    {badge.label}
                  </span>
                  <span className="w-9 text-right font-mono text-[10.5px] text-ink/45">{leader.reportsCount}</span>
                  <span className="w-9 text-right font-mono text-[10.5px] text-ink/45">{leader.resolvedCount}</span>
                  <span className="w-12 text-right font-mono text-[11.5px] font-semibold text-forest">
                    {leader.points}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-[24px] border border-line bg-paper p-5">
            <p className="mono-label">How points are earned</p>
            <div className="mt-3 space-y-2">
              {POINT_RULES.map((rule) => (
                <div key={rule.action} className="flex items-start justify-between gap-3 border-b border-line pb-2 last:border-0 last:pb-0">
                  <div>
                    <p className="text-[11.5px] font-medium leading-snug text-ink/80">{rule.action}</p>
                    <p className="text-[9.5px] uppercase tracking-[0.08em] text-ink/35">{rule.who}</p>
                  </div>
                  <span className="shrink-0 rounded-full bg-lime-soft px-2 py-0.5 font-mono text-[10px] font-semibold text-forest">
                    {rule.points}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[24px] border border-forest/20 bg-moss p-5 text-paper">
            <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-lime">Community summary</p>
            <p className="mt-2 text-[13px] leading-relaxed text-paper/75">
              {stats.resolved} issues resolved out of {stats.totalReports} reported.{" "}
              {stats.duplicatesGrouped} duplicate reports were folded into shared threads, saving{" "}
              {Math.max(1, Math.round(stats.duplicatesGrouped * 0.5))} hours of triage.{" "}
              {bestCategory
                ? `${categoryMeta(bestCategory.category).short} is the most-resolved category with ${bestCategory.resolved} fixes.`
                : ""}
            </p>
            <Link
              href="/report"
              className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-lime px-3.5 py-2 text-[11.5px] font-semibold text-moss hover:bg-lime-soft"
            >
              Add your next small action
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
