import HeatMapClient from "@/components/HeatMapClient";
import { SectionLabel, Stat } from "@/components/ui";
import { getAllReports, getLeaderboard, getPlatformStats } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function HeatmapPage() {
  await ensureSeeded();
  const [allReports, leaders] = await Promise.all([getAllReports(), getLeaderboard()]);
  const stats = await getPlatformStats(allReports, leaders);
  const worst = [...stats.byNeighbourhood].sort((a, b) => b.highPriority - a.highPriority)[0];
  const quietest = [...stats.byNeighbourhood].sort((a, b) => a.total - b.total)[0];

  return (
    <div className="mx-auto max-w-[1180px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <SectionLabel>Location intelligence</SectionLabel>
          <h1 className="display mt-3 max-w-2xl text-[34px] leading-[1.03] sm:text-[44px]">
            Community heatmap, <span className="accent-serif text-forest">block by block.</span>
          </h1>
          <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-ink/60">
            Where reports cluster, attention should follow. Filter by category to see which
            neighbourhoods need a repair visit, a cleanup drive or a stronger light.
          </p>
        </div>
        <div className="rounded-2xl border border-line bg-paper px-4 py-3">
          <p className="mono-label">Priority cluster</p>
          <p className="mt-1 text-[13px] font-semibold">
            {worst?.name ?? "—"} · {worst?.highPriority ?? 0} high priority
          </p>
          <p className="text-[10.5px] text-ink/45">
            Quietest zone: {quietest?.name ?? "—"} · {quietest?.total ?? 0} reports
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat value={stats.byNeighbourhood.length} label="Neighbourhoods mapped" hint="all active zones" />
        <Stat
          value={stats.highPriority}
          label="High-priority open"
          hint="safety and health risks"
        />
        <Stat
          value={stats.open + stats.inProgress}
          label="Active threads"
          hint="open or being worked on"
        />
        <Stat
          value={stats.duplicatesGrouped}
          label="Duplicates collapsed"
          hint="prevents inflated hotspots"
          tone="lime"
        />
      </div>

      <div className="mt-4">
        <HeatMapClient reports={allReports} />
      </div>
    </div>
  );
}
