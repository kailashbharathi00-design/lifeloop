import { readFile, stat } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";

const ZIP_PATH = path.join(
  process.cwd(),
  "public",
  "downloads",
  "lifeloop-ai-web-and-mobile.zip",
);

export async function GET() {
  try {
    const info = await stat(ZIP_PATH);
    const buffer = await readFile(ZIP_PATH);
    return new Response(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="lifeloop-ai-web-and-mobile.zip"',
        "Content-Length": String(info.size),
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return Response.json(
      { error: "Source archive is not available yet." },
      { status: 404 },
    );
  }
}
