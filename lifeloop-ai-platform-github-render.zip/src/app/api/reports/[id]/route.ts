import {
  addNote,
  changeStatus,
  correctCategory,
  getReportDetail,
  recordVote,
} from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";
import { CATEGORIES, type CategoryId, type ReportStatus } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    await ensureSeeded();
    const { id } = await params;
    const reportId = Number(id);
    if (!Number.isFinite(reportId)) {
      return Response.json({ error: "Invalid report id" }, { status: 400 });
    }
    const detail = await getReportDetail(reportId);
    if (!detail) {
      return Response.json({ error: "Report not found" }, { status: 404 });
    }
    return Response.json(detail);
  } catch {
    return Response.json({ error: "Could not load report details." }, { status: 500 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    await ensureSeeded();
    const { id } = await params;
    const reportId = Number(id);
    if (!Number.isFinite(reportId)) {
      return Response.json({ error: "Invalid report id" }, { status: 400 });
    }

    const body = (await request.json()) as Record<string, unknown>;
    const action = typeof body.action === "string" ? body.action : "";
    const user = await getCurrentUser();

    let result: { ok: boolean; message: string };
    switch (action) {
      case "upvote":
      case "verify":
        result = await recordVote(reportId, user.id, action);
        break;
      case "status": {
        const status = body.status;
        if (status !== "open" && status !== "in_progress" && status !== "resolved") {
          return Response.json({ error: "Invalid status" }, { status: 400 });
        }
        result = await changeStatus(
          reportId,
          user.id,
          status as ReportStatus,
          typeof body.note === "string" ? body.note : undefined,
        );
        break;
      }
      case "category": {
        const category = body.category;
        if (typeof category !== "string" || !CATEGORIES.some((item) => item.id === category)) {
          return Response.json({ error: "Invalid category" }, { status: 400 });
        }
        result = await correctCategory(reportId, user.id, category as CategoryId);
        break;
      }
      case "note":
        result = await addNote(
          reportId,
          user.id,
          typeof body.note === "string" ? body.note : "",
        );
        break;
      default:
        return Response.json({ error: "Unknown action" }, { status: 400 });
    }

    if (!result.ok) {
      return Response.json({ error: result.message }, { status: 409 });
    }
    return Response.json({ ok: true, message: result.message });
  } catch {
    return Response.json({ error: "Action failed. Please try again." }, { status: 500 });
  }
}
