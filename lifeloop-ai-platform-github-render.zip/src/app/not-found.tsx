import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-[720px] flex-col items-center px-4 py-24 text-center sm:px-6">
      <span className="rounded-full border border-line bg-paper px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-ink/45">
        Signal lost · 404
      </span>
      <h1 className="display mt-5 text-[38px] leading-[1.03] sm:text-[52px]">
        This thread <span className="accent-serif text-forest">does not exist.</span>
      </h1>
      <p className="mt-4 max-w-md text-[13.5px] leading-relaxed text-ink/60">
        The report may have been removed, or the link was mistyped. Every valid issue lives on the
        shared community dashboard.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-2">
        <Link
          href="/dashboard"
          className="rounded-full bg-forest px-5 py-3 text-[13px] font-semibold text-paper hover:bg-moss"
        >
          Open dashboard
        </Link>
        <Link
          href="/report"
          className="rounded-full border border-line bg-paper px-5 py-3 text-[13px] font-semibold text-ink hover:border-forest/40"
        >
          Report an issue
        </Link>
      </div>
    </div>
  );
}
