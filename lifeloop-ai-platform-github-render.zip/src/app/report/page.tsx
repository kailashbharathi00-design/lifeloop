import Link from "next/link";
import { SectionLabel } from "@/components/ui";
import ReportWizard from "@/components/ReportWizard";
import { CATEGORIES } from "@/lib/types";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ReportPage() {
  const user = await getCurrentUser();
  const samples = CATEGORIES.map((category) => ({
    key: category.id,
    label: category.short,
    image: category.image,
  }));

  return (
    <div className="mx-auto max-w-[1180px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <SectionLabel>Report a community problem</SectionLabel>
          <h1 className="display mt-3 max-w-2xl text-[34px] leading-[1.02] sm:text-[44px]">
            Notice something? <span className="accent-serif text-forest">That is step one.</span>
          </h1>
          <p className="mt-3 max-w-xl text-[13.5px] leading-relaxed text-ink/60">
            Add a photo and a few words. LifeLoop AI identifies the category, estimates urgency,
            finds duplicates and suggests a practical next step — you approve everything before it
            goes live.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 text-[11px]">
          {["Photo optional", "Voice supported", "Editable AI output", "+10 impact points"].map((item) => (
            <span key={item} className="rounded-full border border-line bg-paper px-3 py-1.5 font-medium text-ink/55">
              {item}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-7">
        <ReportWizard
          user={user}
          samples={samples}
        />
      </div>

      <div className="mt-10 grid gap-3 sm:grid-cols-3">
        {[
          {
            title: "Not sure which category?",
            copy: "Describe it in your own words. The text model maps everyday phrasing — including local languages — onto the six categories.",
          },
          {
            title: "Already reported by someone?",
            copy: "Duplicate detection compares wording, category and distance so you can support the existing thread instead of splitting attention.",
          },
          {
            title: "AI got it wrong?",
            copy: "Correct the category or priority on the review screen or later on the report page. Your correction is stored with the AI's original guess.",
          },
        ].map((item) => (
          <div key={item.title} className="rounded-2xl border border-line bg-paper p-4">
            <h3 className="text-[12.5px] font-semibold">{item.title}</h3>
            <p className="mt-1.5 text-[11.5px] leading-relaxed text-ink/55">{item.copy}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-mist/50 px-4 py-3">
        <p className="text-[11.5px] text-ink/55">
          Prefer to look around first? Browse what the community has already reported.
        </p>
        <Link
          href="/dashboard"
          className="rounded-full border border-forest/30 bg-paper px-3.5 py-1.5 text-[11.5px] font-semibold text-forest hover:bg-white"
        >
          Open community dashboard
        </Link>
      </div>
    </div>
  );
}
