"use client";

/* eslint-disable @next/next/no-img-element */
import { useRouter } from "next/navigation";
import { useMemo, useRef, useState } from "react";
import {
  CategoryGlyph,
  ConfidenceMeter,
  PriorityBadge,
} from "@/components/ui";
import {
  CATEGORIES,
  LANGUAGES,
  NEIGHBOURHOODS,
  categoryMeta,
  type AnalysisResult,
  type CategoryId,
  type LeaderRecord,
  type Priority,
} from "@/lib/types";

type ImageFeatures = {
  brightness: number;
  saturation: number;
  greenness: number;
  grayness: number;
};

type Sample = { key: string; label: string; image: string };

const VOICE_LANG: Record<string, string> = {
  en: "en-IN",
  hi: "hi-IN",
  es: "es-ES",
  fr: "fr-FR",
  sw: "sw-KE",
  ar: "ar-SA",
};

const QUICK_STARTS = [
  "Overflowing bins near the market have not been collected for four days and waste is spilling onto the pavement.",
  "A pipe is leaking continuously on the footpath, water is pooling and pedestrians are slipping.",
  "The streetlight has been dark for a week and women walking home after 8pm feel unsafe.",
  "About 60 fresh meals will be thrown away tonight unless a volunteer can collect them.",
];

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  onresult:
    | ((event: { results: { [index: number]: { 0: { transcript: string } } } }) => void)
    | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};

type SpeechCtor = new () => SpeechRecognitionLike;

async function processImage(file: File): Promise<{ dataUrl: string; features: ImageFeatures }> {
  const raw = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read image"));
    reader.readAsDataURL(file);
  });

  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const element = new Image();
    element.onload = () => resolve(element);
    element.onerror = () => reject(new Error("Could not decode image"));
    element.src = raw;
  });

  const maxSize = 1100;
  const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.drawImage(image, 0, 0, width, height);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.72);

  const small = document.createElement("canvas");
  small.width = 24;
  small.height = 24;
  const smallCtx = small.getContext("2d");
  if (!smallCtx) throw new Error("Canvas unavailable");
  smallCtx.drawImage(image, 0, 0, 24, 24);
  const { data } = smallCtx.getImageData(0, 0, 24, 24);

  let brightness = 0;
  let saturation = 0;
  let greenness = 0;
  let grayness = 0;
  const pixels = data.length / 4;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i] / 255;
    const g = data[i + 1] / 255;
    const b = data[i + 2] / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    brightness += (max + min) / 2;
    saturation += max === min ? 0 : (max - min) / (1 - Math.abs(max + min - 1) || 1);
    if (g > r + 0.06 && g > b + 0.04) greenness += 1;
    if (max - min < 0.1) grayness += 1;
  }

  return {
    dataUrl,
    features: {
      brightness: Number((brightness / pixels).toFixed(3)),
      saturation: Number((saturation / pixels).toFixed(3)),
      greenness: Number((greenness / pixels).toFixed(3)),
      grayness: Number((grayness / pixels).toFixed(3)),
    },
  };
}

export default function ReportWizard({
  user,
  samples,
}: {
  user: LeaderRecord;
  samples: Sample[];
}) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);

  const [step, setStep] = useState<1 | 2>(1);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [language, setLanguage] = useState("en");
  const [neighbourhood, setNeighbourhood] = useState(user.neighbourhood || "Old Town");
  const [address, setAddress] = useState("");
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  const [geoNote, setGeoNote] = useState("");
  const [sampleKey, setSampleKey] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [features, setFeatures] = useState<ImageFeatures | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [categoryOverride, setCategoryOverride] = useState<CategoryId | null>(null);
  const [priorityOverride, setPriorityOverride] = useState<Priority | null>(null);
  const [attachTo, setAttachTo] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState("");
  const [listening, setListening] = useState(false);
  const [voiceNote, setVoiceNote] = useState("");
  const recogniser = useRef<SpeechRecognitionLike | null>(null);

  const selectedSample = useMemo(
    () => samples.find((sample) => sample.key === sampleKey) ?? null,
    [samples, sampleKey],
  );

  const effectiveCategory = categoryOverride ?? analysis?.category ?? "garbage";
  const effectivePriority = priorityOverride ?? analysis?.priority ?? "medium";

  function chooseSample(sample: Sample) {
    setSampleKey(sample.key);
    setImageUrl(sample.image);
    setFeatures(null);
  }

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      const result = await processImage(file);
      setImageUrl(result.dataUrl);
      setFeatures(result.features);
      setSampleKey(null);
    } catch {
      setError("That image could not be read. Try a JPG or PNG photo.");
    }
  }

  function toggleVoice() {
    if (listening) {
      recogniser.current?.stop();
      setListening(false);
      return;
    }
    const scope = window as unknown as {
      SpeechRecognition?: SpeechCtor;
      webkitSpeechRecognition?: SpeechCtor;
    };
    const Ctor = scope.SpeechRecognition ?? scope.webkitSpeechRecognition;
    if (!Ctor) {
      setVoiceNote(
        "Voice input is not supported in this browser. Chrome, Edge or Android browsers support it — or simply type the details.",
      );
      return;
    }
    const instance = new Ctor();
    instance.lang = VOICE_LANG[language] ?? "en-IN";
    instance.interimResults = false;
    instance.continuous = false;
    instance.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript ?? "";
      if (transcript) {
        setDescription((current) => (current ? `${current} ${transcript}` : transcript));
        setVoiceNote("Voice note transcribed. Review the text before analysing.");
      }
    };
    instance.onerror = () => setVoiceNote("We could not hear that. Please try again or type instead.");
    instance.onend = () => setListening(false);
    recogniser.current = instance;
    instance.start();
    setListening(true);
    setVoiceNote("Listening… speak in your preferred language.");
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      setGeoNote("Location is unavailable in this browser. Choose your neighbourhood instead.");
      return;
    }
    setGeoNote("Finding your location…");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const nextLat = position.coords.latitude;
        const nextLng = position.coords.longitude;
        setLat(nextLat);
        setLng(nextLng);
        let nearest = NEIGHBOURHOODS[0];
        let best = Number.POSITIVE_INFINITY;
        NEIGHBOURHOODS.forEach((hood) => {
          const distance = Math.hypot(hood.lat - nextLat, hood.lng - nextLng);
          if (distance < best) {
            best = distance;
            nearest = hood;
          }
        });
        setNeighbourhood(nearest.name);
        setGeoNote(
          `Pinned at ${nextLat.toFixed(4)}, ${nextLng.toFixed(4)} — nearest hub ${nearest.name}. Coordinates refine duplicate detection.`,
        );
      },
      () => setGeoNote("Location permission was declined. Your neighbourhood is still enough."),
      { timeout: 8000 },
    );
  }

  async function runAnalysis() {
    setError("");
    if (description.trim().length < 8) {
      setError("Please describe the problem in at least a few words.");
      return;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          language,
          neighbourhood,
          address,
          lat: lat ?? undefined,
          lng: lng ?? undefined,
          imageSampleKey: sampleKey,
          imageFeatures: features,
        }),
      });
      const payload = (await response.json()) as { analysis?: AnalysisResult; error?: string };
      if (!response.ok || !payload.analysis) {
        setError(payload.error ?? "Analysis failed. Please try again.");
        return;
      }
      setAnalysis(payload.analysis);
      setCategoryOverride(null);
      setPriorityOverride(null);
      setAttachTo(
        payload.analysis.duplicateVerdict === "likely_duplicate"
          ? payload.analysis.duplicates[0]?.id ?? null
          : null,
      );
      setStep(2);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("Could not reach the analysis service. Check your connection and retry.");
    } finally {
      setLoading(false);
    }
  }

  async function publish() {
    if (!analysis) return;
    setPublishing(true);
    setError("");
    try {
      const response = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          language,
          neighbourhood,
          address,
          lat: lat ?? undefined,
          lng: lng ?? undefined,
          imageSampleKey: sampleKey,
          imageFeatures: features,
          imageUrl,
          category: effectiveCategory,
          priority: effectivePriority,
          duplicateOfId: attachTo,
        }),
      });
      const payload = (await response.json()) as { id?: number; error?: string };
      if (!response.ok || !payload.id) {
        setError(payload.error ?? "Could not publish the report.");
        return;
      }
      router.push(`/reports/${payload.id}?new=1`);
    } catch {
      setError("Could not publish the report. Please try again.");
    } finally {
      setPublishing(false);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        {[
          { id: 1, label: "Describe the issue", hint: "photo, voice or text" },
          { id: 2, label: "Review AI analysis", hint: "you stay in control" },
        ].map((item, index) => (
          <div key={item.id} className="flex items-center gap-2">
            <div
              className={`flex items-center gap-2.5 rounded-full border px-3 py-1.5 transition ${
                step === item.id
                  ? "border-moss bg-moss text-paper"
                  : step > item.id
                    ? "border-forest/30 bg-lime-soft text-forest"
                    : "border-line bg-paper text-ink/40"
              }`}
            >
              <span
                className={`flex h-5 w-5 items-center justify-center rounded-full font-mono text-[10px] ${
                  step === item.id
                    ? "bg-lime text-moss"
                    : step > item.id
                      ? "bg-forest text-paper"
                      : "bg-mist text-ink/50"
                }`}
              >
                {step > item.id ? "✓" : item.id}
              </span>
              <span className="text-[12px] font-semibold">{item.label}</span>
              <span className={`hidden text-[10px] sm:inline ${step === item.id ? "text-paper/50" : "text-ink/35"}`}>
                {item.hint}
              </span>
            </div>
            {index === 0 && <span className="h-px w-4 bg-line" />}
          </div>
        ))}
      </div>

      {error && (
        <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-[12.5px] text-rose-800">
          {error}
        </div>
      )}

      {step === 1 && (
        <div className="mt-4 grid gap-4 lg:grid-cols-[1.16fr_0.84fr]">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-line bg-paper p-5">
              <div className="flex items-center justify-between gap-3">
                <p className="mono-label">01 · Language</p>
                <span className="text-[10px] text-ink/40">Describe it any way you like</span>
              </div>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {LANGUAGES.map((item) => (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => setLanguage(item.code)}
                    className={`rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition ${
                      language === item.code
                        ? "border-forest bg-lime-soft text-forest"
                        : "border-line bg-bone/60 text-ink/55 hover:text-ink"
                    }`}
                  >
                    {item.native}
                    <span className="ml-1.5 font-mono text-[8.5px] uppercase opacity-55">{item.code}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[22px] border border-line bg-paper p-5">
              <p className="mono-label">02 · What is the problem?</p>
              <input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                maxLength={120}
                placeholder="Short title — e.g. Overflowing bin outside the market"
                className="mt-3 w-full rounded-xl border border-line bg-bone/50 px-3.5 py-3 text-[13.5px] font-medium text-ink placeholder:font-normal placeholder:text-ink/35 focus:border-forest/50 focus:bg-white focus:outline-none"
              />
              <div className="relative mt-2.5">
                <textarea
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  rows={6}
                  maxLength={1500}
                  placeholder="What can you see? Where is it? How long has it been like this? Who is affected?"
                  className="w-full resize-none rounded-xl border border-line bg-bone/50 px-3.5 py-3 text-[13.5px] leading-relaxed text-ink placeholder:text-ink/35 focus:border-forest/50 focus:bg-white focus:outline-none"
                />
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleVoice}
                      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition ${
                        listening
                          ? "border-rose-300 bg-rose-50 text-rose-700"
                          : "border-line bg-bone/60 text-ink/60 hover:text-ink"
                      }`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full ${listening ? "bg-rose-500 pulse-dot" : "bg-forest"}`} />
                      {listening ? "Stop dictation" : "Voice-to-report"}
                    </button>
                    <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-ink/35">
                      {description.length}/1500
                    </span>
                  </div>
                  <span className="text-[10px] text-ink/40">
                    {voiceNote || "Dictation uses your browser's speech engine."}
                  </span>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5">
                {QUICK_STARTS.map((prompt) => (
                  <button
                    key={prompt.slice(0, 24)}
                    type="button"
                    onClick={() => {
                      setDescription(prompt);
                      if (!title) setTitle(prompt.slice(0, 62));
                    }}
                    className="max-w-full truncate rounded-full border border-line bg-white/60 px-2.5 py-1 text-[10.5px] text-ink/50 transition hover:border-forest/30 hover:text-forest"
                  >
                    {prompt.slice(0, 52)}…
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[22px] border border-line bg-paper p-5">
              <div className="flex items-center justify-between">
                <p className="mono-label">03 · Add evidence</p>
                <span className="rounded-full bg-lime-soft px-2 py-0.5 font-mono text-[8.5px] uppercase tracking-[0.1em] text-forest">
                  vision model
                </span>
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-[150px_1fr]">
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="group relative flex h-[150px] flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed border-ink/20 bg-bone/60 text-center transition hover:border-forest/50"
                >
                  {imageUrl ? (
                    <>
                      <img src={imageUrl} alt="Selected evidence" className="absolute inset-0 h-full w-full object-cover" />
                      <span className="absolute inset-0 bg-ink/35" />
                      <span className="relative rounded-full bg-paper/95 px-2.5 py-1 text-[10px] font-semibold text-ink">
                        Replace photo
                      </span>
                    </>
                  ) : (
                    <>
                      <svg viewBox="0 0 24 24" className="h-6 w-6 text-ink/40" fill="none" stroke="currentColor" strokeWidth={1.5} aria-hidden>
                        <rect x="3" y="5" width="18" height="14" rx="2.5" />
                        <circle cx="9" cy="10" r="1.8" />
                        <path d="m5 17 4-4 3 3 3-2 4 3" />
                      </svg>
                      <span className="mt-1.5 text-[11px] font-medium text-ink/60">Upload a photo</span>
                      <span className="mt-0.5 text-[9px] text-ink/35">JPG or PNG · compressed on device</span>
                    </>
                  )}
                </button>

                <div>
                  <p className="text-[10.5px] leading-relaxed text-ink/50">
                    No photo handy? Use a prepared demo frame — each one has a known label, so the
                    vision module behaves exactly like the trained classifier.
                  </p>
                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    {samples.map((sample) => (
                      <button
                        key={sample.key}
                        type="button"
                        onClick={() => chooseSample(sample)}
                        className={`group relative overflow-hidden rounded-lg border text-left transition ${
                          sampleKey === sample.key
                            ? "border-forest ring-2 ring-forest/20"
                            : "border-line hover:border-forest/40"
                        }`}
                      >
                        <img src={sample.image} alt={sample.label} className="h-11 w-full object-cover" />
                        <span className="absolute inset-x-0 bottom-0 bg-ink/70 px-1 py-0.5 text-[8.5px] font-medium text-paper">
                          {sample.label}
                        </span>
                        {selectedSample?.key === sample.key && (
                          <span className="absolute right-0.5 top-0.5 rounded-full bg-lime px-1 text-[8px] font-bold text-moss">
                            ✓
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {features && (
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 rounded-lg bg-mist/60 px-3 py-2 font-mono text-[9px] uppercase tracking-[0.08em] text-ink/50">
                  <span>brightness {features.brightness}</span>
                  <span>saturation {features.saturation}</span>
                  <span>green {features.greenness}</span>
                  <span>neutral {features.grayness}</span>
                  <span className="text-forest">device features extracted</span>
                </div>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => onFile(event.target.files?.[0])}
              />
            </div>

            <div className="rounded-[22px] border border-line bg-paper p-5">
              <p className="mono-label">04 · Where is it?</p>
              <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
                <label className="block">
                  <span className="text-[10.5px] font-medium text-ink/50">Neighbourhood</span>
                  <select
                    value={neighbourhood}
                    onChange={(event) => setNeighbourhood(event.target.value)}
                    className="mt-1 w-full rounded-xl border border-line bg-bone/50 px-3 py-2.5 text-[12.5px] font-medium text-ink focus:border-forest/50 focus:outline-none"
                  >
                    {NEIGHBOURHOODS.map((hood) => (
                      <option key={hood.id} value={hood.name}>
                        {hood.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="text-[10.5px] font-medium text-ink/50">Landmark / street</span>
                  <input
                    value={address}
                    onChange={(event) => setAddress(event.target.value)}
                    placeholder="e.g. Temple Street market gate"
                    className="mt-1 w-full rounded-xl border border-line bg-bone/50 px-3 py-2.5 text-[12.5px] text-ink placeholder:text-ink/35 focus:border-forest/50 focus:outline-none"
                  />
                </label>
              </div>
              <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={useMyLocation}
                  className="inline-flex items-center gap-1.5 rounded-full border border-line bg-bone/60 px-3 py-1.5 text-[11px] font-medium text-ink/60 hover:text-forest"
                >
                  <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={1.7} aria-hidden>
                    <circle cx="12" cy="12" r="3" />
                    <path d="M12 2v3M12 19v3M2 12h3M19 12h3" strokeLinecap="round" />
                  </svg>
                  Use my location
                </button>
                <span className="text-[10px] text-ink/40">
                  {geoNote || "Precise pins improve duplicate detection and hotspot mapping."}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={runAnalysis}
              disabled={loading}
              className="group flex w-full items-center justify-center gap-2 rounded-full bg-forest px-5 py-3.5 text-[13.5px] font-semibold text-paper transition hover:bg-moss disabled:opacity-60"
            >
              {loading ? (
                <>
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-paper/30 border-t-paper" />
                  Analysing photo and text…
                </>
              ) : (
                <>
                  Analyse with LifeLoop AI
                  <svg viewBox="0 0 24 24" className="h-4 w-4 transition group-hover:translate-x-0.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                    <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </>
              )}
            </button>
            <p className="text-center text-[10.5px] text-ink/40">
              Publishing as <span className="font-semibold text-ink/70">{user.name}</span> · You earn +10
              impact points for a verified report
            </p>
          </div>

          <aside className="space-y-3">
            <div className="rounded-[22px] border border-line bg-moss p-5 text-paper">
              <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-lime">
                What happens after you submit
              </p>
              <ol className="mt-3 space-y-3">
                {[
                  ["Vision scan", "The photo is compressed on your device, then matched against damage patterns."],
                  ["Text understanding", "Risk words and issue terms are extracted in your language."],
                  ["Review", "You see the predicted category, priority and duplicates before publishing."],
                  ["Publish", "The thread joins the shared dashboard with an audit trail."],
                ].map(([heading, copy], index) => (
                  <li key={heading} className="flex gap-2.5">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/10 font-mono text-[9px] text-lime">
                      {index + 1}
                    </span>
                    <div>
                      <p className="text-[12px] font-semibold">{heading}</p>
                      <p className="text-[11px] leading-relaxed text-paper/55">{copy}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <div className="rounded-[22px] border border-line bg-paper p-5">
              <p className="mono-label">A good report includes</p>
              <ul className="mt-2.5 space-y-2 text-[11.5px] leading-relaxed text-ink/60">
                {[
                  "One clear problem — not a list of unrelated issues",
                  "A landmark so crews can find it without calling you",
                  "How long it has been like this",
                  "Who is affected (children, elderly, commuters)",
                ].map((item) => (
                  <li key={item} className="flex gap-2">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-forest" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-[22px] border border-dashed border-forest/25 bg-lime-soft/60 p-4">
              <p className="text-[11px] font-semibold text-forest">AI predictions are suggestions</p>
              <p className="mt-1 text-[11px] leading-relaxed text-forest/75">
                You will be able to change the category and priority before publishing, and at any
                time afterwards. Nothing is sent to a civic team automatically in this prototype.
              </p>
            </div>
          </aside>
        </div>
      )}

      {step === 2 && analysis && (
        <div className="mt-4">
          <button
            type="button"
            onClick={() => setStep(1)}
            className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-forest hover:underline"
          >
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
              <path d="M19 12H5M11 6l-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Edit the details
          </button>

          <div className="mt-4 grid gap-4 lg:grid-cols-[1.08fr_0.92fr]">
            <div className="space-y-4">
              <div className="overflow-hidden rounded-[22px] border border-moss/20 bg-moss text-paper">
                <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
                  <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-lime">
                    AI analysis · draft
                  </p>
                  <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-paper/50">
                    {analysis.modelVersion}
                  </span>
                </div>
                <div className="grid gap-4 p-5 sm:grid-cols-[120px_1fr]">
                  <div className="relative h-[120px] overflow-hidden rounded-xl bg-white/10">
                    {imageUrl ? (
                      <img src={imageUrl} alt="Submitted evidence" className="h-full w-full object-cover" />
                    ) : (
                      <div className="grid-paper h-full w-full opacity-20" />
                    )}
                    <div className="scan-frame absolute inset-0" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-lime px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.08em] text-moss">
                        <CategoryGlyph category={effectiveCategory} className="h-3.5 w-3.5" />
                        {categoryMeta(effectiveCategory).label}
                      </span>
                      <PriorityBadge priority={effectivePriority} score={analysis.priorityScore} />
                    </div>
                    <p className="mt-2.5 text-[13px] leading-relaxed text-paper/75">{analysis.summary}</p>
                    <div className="mt-3.5 max-w-xs">
                      <ConfidenceMeter value={analysis.confidence / 100} label="Model confidence" />
                    </div>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {analysis.tags.map((tag) => (
                        <span key={tag} className="rounded-full border border-white/15 bg-white/5 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.06em] text-paper/60">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="border-t border-white/10 px-5 py-3">
                  <p className="text-[10.5px] leading-relaxed text-paper/50">
                    <span className="text-lime">Why:</span> {analysis.priorityReason}
                  </p>
                </div>
              </div>

              <div className="rounded-[22px] border border-line bg-paper p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="mono-label">Human review</p>
                    <h3 className="mt-1 text-[16px] font-semibold">Correct the AI if it is wrong</h3>
                  </div>
                  <span className="rounded-full border border-line bg-bone px-2.5 py-1 text-[10px] font-medium text-ink/50">
                    edits are logged
                  </span>
                </div>

                <p className="mt-4 text-[10.5px] font-semibold uppercase tracking-[0.12em] text-ink/45">
                  Category
                </p>
                <div className="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                  {CATEGORIES.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() =>
                        setCategoryOverride(category.id === analysis.category ? null : category.id)
                      }
                      className={`flex items-center gap-1.5 rounded-xl border px-2.5 py-2 text-left text-[11px] font-medium transition ${
                        effectiveCategory === category.id
                          ? "border-forest bg-lime-soft text-forest"
                          : "border-line bg-bone/50 text-ink/60 hover:border-forest/30"
                      }`}
                    >
                      <CategoryGlyph category={category.id} className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{category.short}</span>
                    </button>
                  ))}
                </div>

                <p className="mt-4 text-[10.5px] font-semibold uppercase tracking-[0.12em] text-ink/45">
                  Suggested priority
                </p>
                <div className="mt-2 grid grid-cols-3 gap-1.5">
                  {(["low", "medium", "high"] as Priority[]).map((priority) => (
                    <button
                      key={priority}
                      type="button"
                      onClick={() =>
                        setPriorityOverride(priority === analysis.priority ? null : priority)
                      }
                      className={`rounded-xl border px-2 py-2 text-[11.5px] font-semibold capitalize transition ${
                        effectivePriority === priority
                          ? "border-forest bg-lime-soft text-forest"
                          : "border-line bg-bone/50 text-ink/55 hover:border-forest/30"
                      }`}
                    >
                      {priority}
                    </button>
                  ))}
                </div>

                {analysis.duplicateVerdict !== "new" && (
                  <div className="mt-4 rounded-xl border border-forest/25 bg-lime-soft/50 p-3">
                    <label className="flex cursor-pointer items-start gap-2.5">
                      <input
                        type="checkbox"
                        checked={attachTo !== null}
                        onChange={(event) =>
                          setAttachTo(event.target.checked ? analysis.duplicates[0]?.id ?? null : null)
                        }
                        className="mt-0.5 h-4 w-4 accent-forest"
                      />
                      <span>
                        <span className="block text-[12px] font-semibold text-forest">
                          Attach as evidence to an existing thread
                        </span>
                        <span className="mt-0.5 block text-[11px] leading-relaxed text-forest/75">
                          Keeps the shared map clean. The original report stays visible and your
                          confirmation still counts.
                        </span>
                      </span>
                    </label>
                  </div>
                )}
              </div>

              <div className="rounded-[22px] border border-line bg-paper p-5">
                <p className="mono-label">Recommended next steps</p>
                <div className="mt-3 space-y-2">
                  {analysis.recommendations.map((recommendation, index) => (
                    <div
                      key={recommendation.title}
                      className="flex gap-3 rounded-xl border border-line bg-bone/40 p-3"
                    >
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-forest font-mono text-[9px] text-lime">
                        {index + 1}
                      </span>
                      <div>
                        <p className="text-[12px] font-semibold text-ink">{recommendation.title}</p>
                        <p className="mt-0.5 text-[11px] leading-relaxed text-ink/55">
                          {recommendation.detail}
                        </p>
                        <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.1em] text-forest/70">
                          owner · {recommendation.owner}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-mist/60 px-3 py-2">
                  <span className="text-[10.5px] text-ink/55">
                    Suggested route: <span className="font-semibold text-ink">{analysis.responsibleDepartment}</span>
                  </span>
                  <span className="font-mono text-[9px] uppercase tracking-[0.1em] text-forest">
                    response guide · {analysis.expectedResponse}
                  </span>
                </div>
              </div>
            </div>

            <aside className="space-y-4">
              <div className="rounded-[22px] border border-line bg-paper p-5">
                <p className="mono-label">Model signals</p>
                <p className="mt-1 text-[11px] text-ink/45">{analysis.signals.reasoning}</p>

                <div className="mt-4 space-y-3">
                  {[
                    { title: "Text model", data: analysis.signals.text },
                    { title: "Vision model", data: analysis.signals.vision },
                  ].map((group) => (
                    <div key={group.title}>
                      <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-ink/40">
                        {group.title}
                      </p>
                      {group.data.length === 0 ? (
                        <p className="mt-1 text-[11px] text-ink/40">No strong signal detected.</p>
                      ) : (
                        <div className="mt-1.5 space-y-1.5">
                          {group.data.map((signal) => (
                            <div key={signal.label} className="flex items-center gap-2">
                              <span className="w-20 shrink-0 truncate text-[10.5px] text-ink/60">
                                {signal.label}
                              </span>
                              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                                <div
                                  className="h-full rounded-full bg-forest/80"
                                  style={{ width: `${Math.min(100, signal.weight)}%` }}
                                />
                              </div>
                              <span className="w-8 text-right font-mono text-[9px] text-ink/40">
                                {signal.weight}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="mt-4 grid gap-2 border-t border-line pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] text-ink/45">Detected language</span>
                    <span className="font-mono text-[10px] uppercase text-ink/70">
                      {analysis.signals.language}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] text-ink/45">Image quality</span>
                    <span className="font-mono text-[10px] uppercase text-ink/70">
                      {analysis.imageQuality}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] text-ink/45">Geo weighting</span>
                    <span className="max-w-[62%] text-right text-[10px] text-ink/60">
                      {analysis.signals.geo}
                    </span>
                  </div>
                </div>
                {analysis.signals.severity.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {analysis.signals.severity.map((item) => (
                      <span key={item} className="rounded-full bg-rose-50 px-2 py-0.5 text-[9.5px] font-medium text-rose-700">
                        {item}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-[22px] border border-line bg-paper p-5">
                <div className="flex items-center justify-between">
                  <p className="mono-label">Duplicate intelligence</p>
                  <span className="rounded-full border border-line bg-bone px-2 py-0.5 font-mono text-[8.5px] uppercase text-ink/45">
                    {analysis.duplicates.length} match{analysis.duplicates.length === 1 ? "" : "es"}
                  </span>
                </div>
                {analysis.duplicates.length === 0 ? (
                  <p className="mt-3 rounded-xl border border-dashed border-forest/20 bg-lime-soft/40 p-3 text-[11px] leading-relaxed text-forest/80">
                    No similar report found nearby. This will become a new action thread.
                  </p>
                ) : (
                  <div className="mt-3 space-y-2">
                    {analysis.duplicates.map((match) => (
                      <div
                        key={match.id}
                        className={`rounded-xl border p-2.5 transition ${
                          attachTo === match.id ? "border-forest bg-lime-soft/50" : "border-line bg-bone/40"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="font-mono text-[9px] text-ink/40">{match.reference} · {match.neighbourhood}</p>
                            <p className="mt-0.5 line-clamp-2 text-[11.5px] font-medium leading-snug text-ink">
                              {match.title}
                            </p>
                          </div>
                          <span className="shrink-0 rounded-full bg-forest px-2 py-0.5 font-mono text-[9px] font-semibold text-lime">
                            {match.similarity}%
                          </span>
                        </div>
                        <p className="mt-1 text-[9.5px] text-ink/45">{match.reason}</p>
                        <div className="mt-1.5 flex items-center justify-between">
                          <a
                            href={`/reports/${match.id}`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] font-semibold text-forest hover:underline"
                          >
                            Open thread ↗
                          </a>
                          <button
                            type="button"
                            onClick={() => setAttachTo(attachTo === match.id ? null : match.id)}
                            className={`rounded-full border px-2 py-0.5 text-[9.5px] font-semibold ${
                              attachTo === match.id
                                ? "border-forest bg-forest text-paper"
                                : "border-line text-ink/50"
                            }`}
                          >
                            {attachTo === match.id ? "attached" : "attach"}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="sticky bottom-4 rounded-[22px] border border-forest/20 bg-paper p-5 shadow-[0_20px_50px_-30px_rgba(11,58,44,0.5)]">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mono-label">Ready to publish</p>
                    <p className="mt-1 text-[13px] font-semibold">
                      {categoryMeta(effectiveCategory).short} · {effectivePriority} priority
                    </p>
                    <p className="text-[10.5px] text-ink/45">
                      {attachTo
                        ? "Attaching to existing thread"
                        : "Creates a new community action thread"}
                    </p>
                  </div>
                  <span className="display text-2xl text-forest">+10</span>
                </div>
                <button
                  type="button"
                  onClick={publish}
                  disabled={publishing}
                  className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-forest px-5 py-3 text-[13px] font-semibold text-paper transition hover:bg-moss disabled:opacity-60"
                >
                  {publishing ? "Publishing…" : "Publish report"}
                  {!publishing && (
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2} aria-hidden>
                      <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                <p className="mt-2 text-center text-[9.5px] leading-relaxed text-ink/40">
                  This prototype stores reports in the community database. No official municipal
                  ticket is created.
                </p>
              </div>
            </aside>
          </div>
        </div>
      )}
    </div>
  );
}
