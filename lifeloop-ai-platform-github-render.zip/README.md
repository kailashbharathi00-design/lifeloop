# LifeLoop AI — Web & Mobile Platform

LifeLoop AI is a community issue-reporting demo with a Next.js web application, REST API, PostgreSQL database, and a Flutter mobile client.

## Project structure

- `src/` — Next.js web app, API routes, database schema and application logic.
- `mobile-flutter/` — Flutter companion app.
- `drizzle.config.ts` — Drizzle ORM database configuration.
- `.env.example` — local environment variable template.

## Requirements

- Node.js 20.9 or newer (Node.js 22 LTS recommended)
- npm
- PostgreSQL database
- Flutter SDK only if you want to run the mobile app

## Run the web app locally

1. Create a PostgreSQL database named `lifeloop` (or use an existing database).
2. Copy `.env.example` to `.env`.
3. Put your PostgreSQL connection string in `.env` as `DATABASE_URL`.
4. From this folder, run:

```bash
npm install
npm run db:push
npm run dev
```

Open `http://localhost:3000`.

Useful commands:

```bash
npm run dev       # development server
npm run build     # production build
npm run start     # production server
npm run typecheck # TypeScript check
npm run lint      # ESLint
npm run db:push   # synchronize Drizzle schema to PostgreSQL
```

The app seeds demo community members and reports on first use. The seed data is illustrative.

## Deploy the web app on GitHub + Render

### 1. Upload to GitHub

Upload the *contents* of this project folder to the root of your GitHub repository. The root must contain `package.json`, `src/`, `mobile-flutter/`, and `drizzle.config.ts`.

Do not upload `.env` or database passwords. `.gitignore` excludes local secrets and generated files.

### 2. Create a PostgreSQL database on Render

1. In the Render dashboard, create a PostgreSQL database.
2. Choose a region.
3. Copy its **Internal Database URL**. The web service should be in the same region.

### 3. Create a Render Web Service

Connect the GitHub repository and use:

- Runtime: Node
- Build command: `npm install && npm run db:push && npm run build`
- Start command: `npm run start`

Add this environment variable in the Render service:

- `DATABASE_URL` = the Render PostgreSQL **Internal Database URL**

Deploy the service. Check `https://YOUR-SERVICE.onrender.com/api/health`; a successful database connection returns `{"ok":true}`.

**Note:** `db:push` updates the database schema during deployment. For a production system with important data, use reviewed migrations and backups rather than automatic schema pushes.

## Flutter mobile app

The Flutter client is in `mobile-flutter/` and uses the shared web API.

1. Install Flutter.
2. Start the web backend locally.
3. From `mobile-flutter/`, run:

```bash
flutter pub get
```

For an Android emulator:

```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000
```

For an iOS simulator:

```bash
flutter run --dart-define=API_BASE_URL=http://localhost:3000
```

For a physical phone, use your computer's LAN IP address instead of `localhost`, and ensure both devices are on the same network.

## Important implementation notes

- The included analysis logic is implemented in the project code; this package does not include an external AI provider key or a hosted AI model integration.
- Demo seed records are sample data, not real community reports.
- The API uses a demo member/session flow. Add authentication, authorization, rate limiting, input hardening, and privacy controls before public production use.
- Never commit `.env`, API keys, database URLs, or credentials.
