# LifeLoop AI — Flutter Mobile App

Companion Flutter mobile client for **LifeLoop AI** (*"Small actions. Smart intelligence. Better tomorrow."*).  
Connects directly to the shared Next.js + PostgreSQL backend API (`/api/reports`, `/api/reports/:id`, `/api/analyze`, `/api/session`).

## Features
- **Community Dashboard** — live stats, category filters, search, duplicate thread badges
- **AI Report Wizard** — camera/gallery photo capture or demo frames, multilingual selection, AI categorization & priority scoring, duplicate detection, and human override controls
- **Report Detail Thread** — Support/Verify buttons, AI recommendations, status updates, and action timeline
- **Community Heatmap** — neighbourhood hotspot bubbles and rankings
- **Green Impact Leaderboard** — community points and contributor rankings

## Run locally
1. Start the web & API backend from the repository root:
   ```bash
   npm install
   npx drizzle-kit push
   npm run dev
   ```
2. Run the Flutter app:
   ```bash
   cd mobile-flutter
   flutter create . --platforms=android,ios
   flutter pub get
   # Android emulator:
   flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000
   # iOS simulator or desktop:
   flutter run --dart-define=API_BASE_URL=http://localhost:3000
   ```
