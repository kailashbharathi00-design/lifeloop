import 'package:flutter/material.dart';
import '../models/lifeloop_models.dart';
import '../services/api_client.dart';
import '../theme/lifeloop_theme.dart';
import 'report_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  final LifeLoopApiClient api;
  final DashboardBundle bundle;
  final Future<void> Function() onRefresh;

  const DashboardScreen({
    super.key,
    required this.api,
    required this.bundle,
    required this.onRefresh,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _selectedCategory = 'all';
  String _query = '';
  bool _onlyGrouped = false;

  List<ReportItem> get _filtered {
    return widget.bundle.reports.where((report) {
      if (_selectedCategory != 'all' && report.category != _selectedCategory) {
        return false;
      }
      if (_onlyGrouped && report.duplicateCount == 0) {
        return false;
      }
      if (_query.trim().isNotEmpty) {
        final q = _query.toLowerCase();
        final hay =
            '${report.title} ${report.description} ${report.neighbourhood} ${report.reference}'
                .toLowerCase();
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final stats = widget.bundle.stats;
    final items = _filtered;

    return RefreshIndicator(
      color: LifeLoopColors.forest,
      onRefresh: widget.onRefresh,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: LifeLoopColors.moss,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'SMALL ACTIONS · SMART INTELLIGENCE',
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 1.6,
                    fontWeight: FontWeight.w600,
                    color: LifeLoopColors.lime,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Community Dashboard',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: LifeLoopColors.paper,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _MiniMetric(value: '${stats.totalReports}', label: 'Reports'),
                    const SizedBox(width: 10),
                    _MiniMetric(value: '${stats.resolved}', label: 'Resolved'),
                    const SizedBox(width: 10),
                    _MiniMetric(value: '${stats.duplicatesGrouped}', label: 'Grouped'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            onChanged: (value) => setState(() => _query = value),
            decoration: const InputDecoration(
              hintText: 'Search issue, street, or reference…',
              prefixIcon: Icon(Icons.search, size: 20),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _FilterChip(
                  label: 'All',
                  selected: _selectedCategory == 'all',
                  onTap: () => setState(() => _selectedCategory = 'all'),
                ),
                ...kCategories.map(
                  (c) => _FilterChip(
                    label: c.shortLabel,
                    selected: _selectedCategory == c.id,
                    onTap: () => setState(
                      () => _selectedCategory = _selectedCategory == c.id ? 'all' : c.id,
                    ),
                  ),
                ),
                _FilterChip(
                  label: 'Grouped only',
                  selected: _onlyGrouped,
                  onTap: () => setState(() => _onlyGrouped = !_onlyGrouped),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Showing ${items.length} of ${widget.bundle.reports.length} reports',
            style: TextStyle(
              fontSize: 12,
              color: LifeLoopColors.ink.withValues(alpha: 0.55),
            ),
          ),
          const SizedBox(height: 10),
          if (items.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('No reports match your current filters.'),
              ),
            )
          else
            ...items.map(
              (report) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _ReportListCard(
                  report: report,
                  onTap: () async {
                    await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ReportDetailScreen(
                          api: widget.api,
                          reportId: report.id,
                        ),
                      ),
                    );
                    await widget.onRefresh();
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  final String value;
  final String label;

  const _MiniMetric({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: LifeLoopColors.lime,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: LifeLoopColors.paper.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        selectedColor: LifeLoopColors.moss,
        backgroundColor: LifeLoopColors.paper,
        labelStyle: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: selected ? LifeLoopColors.paper : LifeLoopColors.ink,
        ),
        side: const BorderSide(color: LifeLoopColors.line),
      ),
    );
  }
}

class _ReportListCard extends StatelessWidget {
  final ReportItem report;
  final VoidCallback onTap;

  const _ReportListCard({required this.report, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final meta = categoryById(report.category);
    final pct = (report.aiConfidence * 100).round();

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (report.imageUrl != null && report.imageUrl!.startsWith('http'))
              SizedBox(
                height: 150,
                width: double.infinity,
                child: Image.network(
                  report.imageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: LifeLoopColors.mist),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        report.reference,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: LifeLoopColors.forest,
                        ),
                      ),
                      const Spacer(),
                      _Pill(
                        text: report.priority.toUpperCase(),
                        bg: report.priority == 'high'
                            ? const Color(0xFFFFE4E6)
                            : LifeLoopColors.limeSoft,
                        fg: report.priority == 'high'
                            ? const Color(0xFFBE123C)
                            : LifeLoopColors.forest,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    report.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: LifeLoopColors.ink,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(meta.icon, size: 15, color: meta.color),
                      const SizedBox(width: 5),
                      Text(
                        '${meta.shortLabel} · ${report.neighbourhood}',
                        style: TextStyle(
                          fontSize: 12,
                          color: LifeLoopColors.ink.withValues(alpha: 0.6),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: report.aiConfidence.clamp(0.0, 1.0),
                    minHeight: 5,
                    borderRadius: BorderRadius.circular(99),
                    backgroundColor: LifeLoopColors.mist,
                    color: LifeLoopColors.forest,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text(
                        'AI confidence $pct% · ${report.status.replaceAll('_', ' ')}',
                        style: TextStyle(
                          fontSize: 11,
                          color: LifeLoopColors.ink.withValues(alpha: 0.55),
                        ),
                      ),
                      const Spacer(),
                      if (report.duplicateCount > 0)
                        Text(
                          '${report.duplicateCount} linked',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: LifeLoopColors.forest,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;

  const _Pill({required this.text, required this.bg, required this.fg});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
      child: Text(
        text,
        style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: fg),
      ),
    );
  }
}
