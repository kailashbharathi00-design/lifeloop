import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/lifeloop_models.dart';
import '../services/api_client.dart';
import '../theme/lifeloop_theme.dart';
import 'report_detail_screen.dart';

class ReportScreen extends StatefulWidget {
  final LifeLoopApiClient api;
  final Future<void> Function() onPublished;

  const ReportScreen({
    super.key,
    required this.api,
    required this.onPublished,
  });

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _addressController = TextEditingController();
  final _picker = ImagePicker();

  String _language = 'en';
  String _neighbourhood = kNeighbourhoods.first;
  String? _sampleKey;
  String? _imageUrl;
  File? _pickedFile;

  AnalysisResult? _analysis;
  String? _categoryOverride;
  String? _priorityOverride;
  int? _attachToId;
  bool _loading = false;
  bool _publishing = false;
  String? _error;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource source) async {
    final picked = await _picker.pickImage(source: source, maxWidth: 1024, imageQuality: 72);
    if (picked == null) return;
    final bytes = await picked.readAsBytes();
    setState(() {
      _pickedFile = File(picked.path);
      _sampleKey = null;
      _imageUrl = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    });
  }

  Future<void> _runAnalysis() async {
    if (_descriptionController.text.trim().length < 8) {
      setState(() => _error = 'Please describe the problem in at least a few words.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await widget.api.analyzeProblem(
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        language: _language,
        neighbourhood: _neighbourhood,
        address: _addressController.text.trim(),
        imageSampleKey: _sampleKey,
      );
      setState(() {
        _analysis = result;
        _categoryOverride = null;
        _priorityOverride = null;
        _attachToId = result.duplicateVerdict == 'likely_duplicate' && result.duplicates.isNotEmpty
            ? result.duplicates.first.id
            : null;
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _publish() async {
    final analysis = _analysis;
    if (analysis == null) return;
    setState(() {
      _publishing = true;
      _error = null;
    });
    try {
      final id = await widget.api.publishReport(
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        language: _language,
        neighbourhood: _neighbourhood,
        address: _addressController.text.trim(),
        imageSampleKey: _sampleKey,
        imageUrl: _imageUrl,
        category: _categoryOverride ?? analysis.category,
        priority: _priorityOverride ?? analysis.priority,
        duplicateOfId: _attachToId,
      );
      await widget.onPublished();
      if (!mounted) return;
      _titleController.clear();
      _descriptionController.clear();
      _addressController.clear();
      setState(() {
        _analysis = null;
        _pickedFile = null;
        _sampleKey = null;
        _imageUrl = null;
      });
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ReportDetailScreen(api: widget.api, reportId: id),
        ),
      );
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _publishing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final analysis = _analysis;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        const Text(
          'Report a problem',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 4),
        Text(
          'Snap a photo or describe an everyday issue. AI suggests category, urgency and duplicates — you stay in control.',
          style: TextStyle(fontSize: 13, color: LifeLoopColors.ink.withValues(alpha: 0.65)),
        ),
        if (_error != null) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF1F2),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFFECDD3)),
            ),
            child: Text(_error!, style: const TextStyle(color: Color(0xFF9F1239), fontSize: 12)),
          ),
        ],
        const SizedBox(height: 14),
        if (analysis == null) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('01 · Language', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: kLanguages.entries
                        .map(
                          (entry) => ChoiceChip(
                            label: Text(entry.value),
                            selected: _language == entry.key,
                            onSelected: (_) => setState(() => _language = entry.key),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 14),
                  const Text('02 · Issue details', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      hintText: 'Short title (e.g. Overflowing bins near market)',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _descriptionController,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      hintText: 'Describe what is wrong, how long it has been there, and who is affected…',
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('03 · Evidence photo or demo frame', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _pickPhoto(ImageSource.camera),
                          icon: const Icon(Icons.camera_alt_outlined, size: 18),
                          label: const Text('Camera'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _pickPhoto(ImageSource.gallery),
                          icon: const Icon(Icons.photo_library_outlined, size: 18),
                          label: const Text('Gallery'),
                        ),
                      ),
                    ],
                  ),
                  if (_pickedFile != null) ...[
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Image.file(_pickedFile!, height: 140, width: double.infinity, fit: BoxFit.cover),
                    ),
                  ],
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: kCategories
                        .map(
                          (cat) => ChoiceChip(
                            label: Text('Demo: ${cat.shortLabel}'),
                            selected: _sampleKey == cat.id,
                            onSelected: (_) => setState(() {
                              _pickedFile = null;
                              _sampleKey = cat.id;
                              _imageUrl = cat.sampleImageUrl;
                            }),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 14),
                  const Text('04 · Location', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    initialValue: _neighbourhood,
                    items: kNeighbourhoods
                        .map((h) => DropdownMenuItem(value: h, child: Text(h)))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _neighbourhood = v);
                    },
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _addressController,
                    decoration: const InputDecoration(hintText: 'Landmark or street name'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: LifeLoopColors.forest,
              foregroundColor: LifeLoopColors.paper,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
            ),
            onPressed: _loading ? null : _runAnalysis,
            child: Text(_loading ? 'Analysing with LifeLoop AI…' : 'Analyse with LifeLoop AI'),
          ),
        ] else ...[
          TextButton.icon(
            onPressed: () => setState(() => _analysis = null),
            icon: const Icon(Icons.arrow_back, size: 16),
            label: const Text('Edit details'),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: LifeLoopColors.moss,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AI ANALYSIS · ${analysis.confidence}% CONFIDENCE',
                  style: const TextStyle(
                    fontSize: 10,
                    letterSpacing: 1.5,
                    color: LifeLoopColors.lime,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${categoryById(_categoryOverride ?? analysis.category).label} · ${(_priorityOverride ?? analysis.priority).toUpperCase()} (${analysis.priorityScore}/100)',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: LifeLoopColors.paper,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  analysis.summary,
                  style: TextStyle(fontSize: 13, color: LifeLoopColors.paper.withValues(alpha: 0.85)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Human review (override AI if needed)', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: kCategories
                        .map(
                          (cat) => ChoiceChip(
                            label: Text(cat.shortLabel),
                            selected: (_categoryOverride ?? analysis.category) == cat.id,
                            onSelected: (_) => setState(() => _categoryOverride = cat.id),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    children: ['low', 'medium', 'high']
                        .map(
                          (p) => ChoiceChip(
                            label: Text(p.toUpperCase()),
                            selected: (_priorityOverride ?? analysis.priority) == p,
                            onSelected: (_) => setState(() => _priorityOverride = p),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),
            ),
          ),
          if (analysis.duplicates.isNotEmpty) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Duplicate intelligence', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    ...analysis.duplicates.map(
                      (dup) => CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: _attachToId == dup.id,
                        onChanged: (checked) => setState(() => _attachToId = checked == true ? dup.id : null),
                        title: Text('${dup.reference} · ${dup.title} (${dup.similarity}%)', style: const TextStyle(fontSize: 13)),
                        subtitle: Text(dup.reason, style: const TextStyle(fontSize: 11)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 14),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: LifeLoopColors.forest,
              foregroundColor: LifeLoopColors.paper,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
            ),
            onPressed: _publishing ? null : _publish,
            child: Text(_publishing ? 'Publishing…' : 'Publish report (+10 pts)'),
          ),
        ],
      ],
    );
  }
}
