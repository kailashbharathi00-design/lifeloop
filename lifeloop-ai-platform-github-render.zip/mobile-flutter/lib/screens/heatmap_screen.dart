import 'package:flutter/material.dart';
import '../models/lifeloop_models.dart';
import '../theme/lifeloop_theme.dart';

class HeatmapScreen extends StatelessWidget {
  final PlatformStats stats;

  const HeatmapScreen({super.key, required this.stats});

  @override
  Widget build(BuildContext context) {
    final sorted = [...stats.byNeighbourhood]..sort((a, b) => b.total.compareTo(a.total));
    final maxTotal = sorted.isEmpty ? 1 : (sorted.first.total == 0 ? 1 : sorted.first.total);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        const Text(
          'Community Problem Heatmap',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 4),
        Text(
          'Hotspot density across ${sorted.length} neighbourhoods. Duplicates are collapsed so counts reflect real issues.',
          style: TextStyle(fontSize: 13, color: LifeLoopColors.ink.withValues(alpha: 0.65)),
        ),
        const SizedBox(height: 14),
        Container(
          height: 220,
          decoration: BoxDecoration(
            color: LifeLoopColors.paper,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: LifeLoopColors.line),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: sorted.map((zone) {
                  final radius = 16 + (zone.total / maxTotal) * 20;
                  final left = (zone.x / 100) * (constraints.maxWidth - 60) + 12;
                  final top = (zone.y / 100) * (constraints.maxHeight - 50) + 10;
                  final isHot = zone.highPriority > 0;
                  return Positioned(
                    left: left,
                    top: top,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: radius * 1.4,
                          height: radius * 1.4,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: (isHot ? LifeLoopColors.clay : LifeLoopColors.forest)
                                .withValues(alpha: 0.85),
                            border: Border.all(color: LifeLoopColors.paper, width: 2),
                          ),
                          child: Text(
                            '${zone.total}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 11,
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(zone.name, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        ...sorted.map(
          (zone) => Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              title: Text(zone.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${zone.open} open · ${zone.resolved} resolved · ${zone.highPriority} high priority'),
              trailing: CircleAvatar(
                backgroundColor: LifeLoopColors.moss,
                foregroundColor: LifeLoopColors.lime,
                child: Text('${zone.total}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
