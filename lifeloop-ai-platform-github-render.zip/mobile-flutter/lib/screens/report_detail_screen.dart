import 'package:flutter/material.dart';
import '../models/lifeloop_models.dart';
import '../services/api_client.dart';
import '../theme/lifeloop_theme.dart';

class ReportDetailScreen extends StatefulWidget {
  final LifeLoopApiClient api;
  final int reportId;

  const ReportDetailScreen({
    super.key,
    required this.api,
    required this.reportId,
  });

  @override
  State<ReportDetailScreen> createState() => _ReportDetailScreenState();
}

class _ReportDetailScreenState extends State<ReportDetailScreen> {
  final _noteController = TextEditingController();
  ReportDetailBundle? _detail;
  bool _loading = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await widget.api.fetchReportDetail(widget.reportId);
      setState(() => _detail = data);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _act(Map<String, dynamic> payload) async {
    setState(() => _busy = true);
    try {
      final msg = await widget.api.performReportAction(widget.reportId, payload);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
      }
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_detail?.report.reference ?? 'Report detail')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null || _detail == null
              ? Center(child: Text(_error ?? 'Report not found'))
              : _buildBody(_detail!),
    );
  }

  Widget _buildBody(ReportDetailBundle bundle) {
    final r = bundle.report;
    final meta = categoryById(r.category);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        if (r.imageUrl != null && r.imageUrl!.startsWith('http'))
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.network(r.imageUrl!, height: 200, width: double.infinity, fit: BoxFit.cover),
          ),
        const SizedBox(height: 14),
        Text(
          '${meta.label} · ${r.priority.toUpperCase()} (${r.priorityScore}/100)',
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: LifeLoopColors.forest),
        ),
        const SizedBox(height: 6),
        Text(r.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(
          '${r.neighbourhood} · ${r.address} · Status: ${r.status.replaceAll('_', ' ')}',
          style: TextStyle(fontSize: 12, color: LifeLoopColors.ink.withValues(alpha: 0.6)),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(r.description, style: const TextStyle(fontSize: 14, height: 1.45)),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: LifeLoopColors.forest),
                onPressed: _busy ? null : () => _act({'action': 'upvote'}),
                icon: const Icon(Icons.thumb_up_outlined, size: 18),
                label: Text('Support (${r.upvotes})'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _busy ? null : () => _act({'action': 'verify'}),
                icon: const Icon(Icons.verified_outlined, size: 18),
                label: Text('Verify (${r.verifications})'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('AI Recommendations', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...r.recommendations.map(
                  (rec) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(rec.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                        Text(rec.detail, style: const TextStyle(fontSize: 12)),
                        Text('Owner: ${rec.owner}', style: const TextStyle(fontSize: 11, color: LifeLoopColors.forest)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Update status or add a note', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  children: ['open', 'in_progress', 'resolved']
                      .map(
                        (status) => ChoiceChip(
                          label: Text(status.replaceAll('_', ' ')),
                          selected: r.status == status,
                          onSelected: _busy || r.status == status
                              ? null
                              : (_) => _act({'action': 'status', 'status': status}),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _noteController,
                  decoration: const InputDecoration(hintText: 'Share a field update…'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: LifeLoopColors.moss),
                    onPressed: _busy
                        ? null
                        : () {
                            final text = _noteController.text.trim();
                            if (text.isEmpty) return;
                            _noteController.clear();
                            _act({'action': 'note', 'note': text});
                          },
                    child: const Text('Post update'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Action trail (${bundle.updates.length})', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...bundle.updates.map(
                  (u) => ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.circle, size: 10, color: LifeLoopColors.forest),
                    title: Text(u.note, style: const TextStyle(fontSize: 13)),
                    subtitle: Text('${u.actorName} · ${u.kind}', style: const TextStyle(fontSize: 11)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
