import 'package:flutter/material.dart';
import '../models/lifeloop_models.dart';
import '../theme/lifeloop_theme.dart';

class ImpactScreen extends StatelessWidget {
  final PlatformStats stats;
  final List<LeaderItem> leaders;

  const ImpactScreen({
    super.key,
    required this.stats,
    required this.leaders,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        const Text(
          'Green Impact Points',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 4),
        Text(
          '${stats.impactPoints} points earned across ${stats.neighbours} active residents · ${stats.resolutionRate}% resolution rate.',
          style: TextStyle(fontSize: 13, color: LifeLoopColors.ink.withValues(alpha: 0.65)),
        ),
        const SizedBox(height: 14),
        ...leaders.asMap().entries.map((entry) {
          final index = entry.key;
          final leader = entry.value;
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            color: index == 0 ? LifeLoopColors.limeSoft : LifeLoopColors.paper,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: index == 0 ? LifeLoopColors.moss : LifeLoopColors.mist,
                foregroundColor: index == 0 ? LifeLoopColors.lime : LifeLoopColors.ink,
                child: Text('${index + 1}', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              title: Text(leader.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${leader.neighbourhood} · ${leader.reportsCount} reports · ${leader.resolvedCount} resolved'),
              trailing: Text(
                '${leader.points} pts',
                style: const TextStyle(fontWeight: FontWeight.w800, color: LifeLoopColors.forest),
              ),
            ),
          );
        }),
      ],
    );
  }
}
