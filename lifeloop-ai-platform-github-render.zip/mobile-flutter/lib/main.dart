import 'package:flutter/material.dart';
import 'models/lifeloop_models.dart';
import 'screens/dashboard_screen.dart';
import 'screens/heatmap_screen.dart';
import 'screens/impact_screen.dart';
import 'screens/report_screen.dart';
import 'services/api_client.dart';
import 'theme/lifeloop_theme.dart';

void main() {
  runApp(const LifeLoopApp());
}

class LifeLoopApp extends StatelessWidget {
  const LifeLoopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LifeLoop AI',
      debugShowCheckedModeBanner: false,
      theme: LifeLoopTheme.build(),
      home: const LifeLoopHomeShell(),
    );
  }
}

class LifeLoopHomeShell extends StatefulWidget {
  const LifeLoopHomeShell({super.key});

  @override
  State<LifeLoopHomeShell> createState() => _LifeLoopHomeShellState();
}

class _LifeLoopHomeShellState extends State<LifeLoopHomeShell> {
  final LifeLoopApiClient _api = LifeLoopApiClient();
  int _tab = 0;
  DashboardBundle? _bundle;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await _api.fetchDashboard();
      setState(() => _bundle = data);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.eco, color: LifeLoopColors.forest),
            SizedBox(width: 8),
            Text('LifeLoop AI', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading && _bundle == null
          ? const Center(child: CircularProgressIndicator())
          : _error != null && _bundle == null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Could not connect to ${_api.baseUrl}', textAlign: TextAlign.center),
                        const SizedBox(height: 8),
                        Text(_error!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 14),
                        FilledButton(onPressed: _load, child: const Text('Retry')),
                      ],
                    ),
                  ),
                )
              : IndexedStack(
                  index: _tab,
                  children: [
                    DashboardScreen(api: _api, bundle: _bundle!, onRefresh: _load),
                    ReportScreen(api: _api, onPublished: _load),
                    HeatmapScreen(stats: _bundle!.stats),
                    ImpactScreen(stats: _bundle!.stats, leaders: _bundle!.leaders),
                  ],
                ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        backgroundColor: LifeLoopColors.paper,
        indicatorColor: LifeLoopColors.limeSoft,
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.add_a_photo_outlined), label: 'Report'),
          NavigationDestination(icon: Icon(Icons.map_outlined), label: 'Heatmap'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Impact'),
        ],
      ),
    );
  }
}
