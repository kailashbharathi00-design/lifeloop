import 'package:flutter/material.dart';

class LifeLoopColors {
  static const Color bone = Color(0xFFF2F1E8);
  static const Color paper = Color(0xFFFBFBF5);
  static const Color ink = Color(0xFF0D1F18);
  static const Color moss = Color(0xFF0B3A2C);
  static const Color forest = Color(0xFF146349);
  static const Color leaf = Color(0xFF2F8F68);
  static const Color lime = Color(0xFFD9F47A);
  static const Color limeSoft = Color(0xFFEEF9C9);
  static const Color clay = Color(0xFFE0784F);
  static const Color line = Color(0xFFE2E2D5);
  static const Color mist = Color(0xFFEEF0E6);
}

class LifeLoopTheme {
  static ThemeData build() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: LifeLoopColors.bone,
      colorScheme: ColorScheme.fromSeed(
        seedColor: LifeLoopColors.forest,
        primary: LifeLoopColors.forest,
        secondary: LifeLoopColors.lime,
        surface: LifeLoopColors.paper,
        onSurface: LifeLoopColors.ink,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: LifeLoopColors.bone,
        foregroundColor: LifeLoopColors.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: CardThemeData(
        color: LifeLoopColors.paper,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: LifeLoopColors.line),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: LifeLoopColors.bone,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: LifeLoopColors.line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: LifeLoopColors.line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: LifeLoopColors.forest, width: 1.5),
        ),
      ),
    );
  }
}
