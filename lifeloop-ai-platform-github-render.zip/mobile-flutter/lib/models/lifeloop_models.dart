import 'package:flutter/material.dart';

class CategoryOption {
  final String id;
  final String label;
  final String shortLabel;
  final IconData icon;
  final Color color;
  final String sampleImageUrl;

  const CategoryOption({
    required this.id,
    required this.label,
    required this.shortLabel,
    required this.icon,
    required this.color,
    required this.sampleImageUrl,
  });
}

const List<CategoryOption> kCategories = [
  CategoryOption(
    id: 'garbage',
    label: 'Garbage accumulation',
    shortLabel: 'Garbage',
    icon: Icons.delete_outline,
    color: Color(0xFF146349),
    sampleImageUrl:
        'https://images.pexels.com/photos/6316243/pexels-photo-6316243.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
  CategoryOption(
    id: 'water',
    label: 'Water leakage',
    shortLabel: 'Water',
    icon: Icons.water_drop_outlined,
    color: Color(0xFF0E7490),
    sampleImageUrl:
        'https://images.pexels.com/photos/4406597/pexels-photo-4406597.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
  CategoryOption(
    id: 'roads',
    label: 'Road damage',
    shortLabel: 'Roads',
    icon: Icons.add_road_outlined,
    color: Color(0xFFB45309),
    sampleImageUrl:
        'https://images.pexels.com/photos/11849379/pexels-photo-11849379.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
  CategoryOption(
    id: 'lighting',
    label: 'Streetlight failure',
    shortLabel: 'Lighting',
    icon: Icons.lightbulb_outline,
    color: Color(0xFF4338CA),
    sampleImageUrl:
        'https://images.pexels.com/photos/9809601/pexels-photo-9809601.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
  CategoryOption(
    id: 'food',
    label: 'Food wastage',
    shortLabel: 'Food',
    icon: Icons.restaurant_outlined,
    color: Color(0xFFBE123C),
    sampleImageUrl:
        'https://images.pexels.com/photos/36593268/pexels-photo-36593268.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
  CategoryOption(
    id: 'infrastructure',
    label: 'Public infrastructure',
    shortLabel: 'Infrastructure',
    icon: Icons.handyman_outlined,
    color: Color(0xFF0F766E),
    sampleImageUrl:
        'https://images.pexels.com/photos/11658940/pexels-photo-11658940.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  ),
];

const List<String> kNeighbourhoods = [
  'Old Town',
  'Riverside',
  'Green Park',
  'Market Quarter',
  'Lakeview',
  'Northgate',
  'Tech Park',
  'Sunrise Colony',
];

const Map<String, String> kLanguages = {
  'en': 'English',
  'hi': 'हिन्दी',
  'es': 'Español',
  'fr': 'Français',
  'sw': 'Kiswahili',
  'ar': 'العربية',
};

CategoryOption categoryById(String id) {
  return kCategories.firstWhere(
    (item) => item.id == id,
    orElse: () => kCategories.first,
  );
}

class RecommendationItem {
  final String title;
  final String detail;
  final String owner;

  const RecommendationItem({
    required this.title,
    required this.detail,
    required this.owner,
  });

  factory RecommendationItem.fromJson(Map<String, dynamic> json) {
    return RecommendationItem(
      title: (json['title'] ?? '').toString(),
      detail: (json['detail'] ?? '').toString(),
      owner: (json['owner'] ?? 'Community').toString(),
    );
  }
}

class DuplicateMatch {
  final int id;
  final String reference;
  final String title;
  final String category;
  final String status;
  final String neighbourhood;
  final int similarity;
  final int distanceMeters;
  final String reason;

  const DuplicateMatch({
    required this.id,
    required this.reference,
    required this.title,
    required this.category,
    required this.status,
    required this.neighbourhood,
    required this.similarity,
    required this.distanceMeters,
    required this.reason,
  });

  factory DuplicateMatch.fromJson(Map<String, dynamic> json) {
    return DuplicateMatch(
      id: (json['id'] as num?)?.toInt() ?? 0,
      reference: (json['reference'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      category: (json['category'] ?? 'garbage').toString(),
      status: (json['status'] ?? 'open').toString(),
      neighbourhood: (json['neighbourhood'] ?? '').toString(),
      similarity: (json['similarity'] as num?)?.toInt() ?? 0,
      distanceMeters: (json['distanceMeters'] as num?)?.toInt() ?? 0,
      reason: (json['reason'] ?? '').toString(),
    );
  }
}

class AnalysisResult {
  final String category;
  final String categoryLabel;
  final int confidence;
  final String priority;
  final int priorityScore;
  final String priorityReason;
  final String summary;
  final List<String> tags;
  final List<RecommendationItem> recommendations;
  final String responsibleDepartment;
  final String expectedResponse;
  final List<DuplicateMatch> duplicates;
  final String duplicateVerdict;
  final String modelVersion;

  const AnalysisResult({
    required this.category,
    required this.categoryLabel,
    required this.confidence,
    required this.priority,
    required this.priorityScore,
    required this.priorityReason,
    required this.summary,
    required this.tags,
    required this.recommendations,
    required this.responsibleDepartment,
    required this.expectedResponse,
    required this.duplicates,
    required this.duplicateVerdict,
    required this.modelVersion,
  });

  factory AnalysisResult.fromJson(Map<String, dynamic> json) {
    return AnalysisResult(
      category: (json['category'] ?? 'garbage').toString(),
      categoryLabel: (json['categoryLabel'] ?? 'Garbage accumulation').toString(),
      confidence: (json['confidence'] as num?)?.toInt() ?? 75,
      priority: (json['priority'] ?? 'medium').toString(),
      priorityScore: (json['priorityScore'] as num?)?.toInt() ?? 50,
      priorityReason: (json['priorityReason'] ?? '').toString(),
      summary: (json['summary'] ?? '').toString(),
      tags: (json['tags'] as List? ?? const []).map((e) => e.toString()).toList(),
      recommendations: (json['recommendations'] as List? ?? const [])
          .map((e) => RecommendationItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      responsibleDepartment: (json['responsibleDepartment'] ?? '').toString(),
      expectedResponse: (json['expectedResponse'] ?? '').toString(),
      duplicates: (json['duplicates'] as List? ?? const [])
          .map((e) => DuplicateMatch.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      duplicateVerdict: (json['duplicateVerdict'] ?? 'new').toString(),
      modelVersion: (json['modelVersion'] ?? 'lifeloop-vision-2.1').toString(),
    );
  }
}

class ReportItem {
  final int id;
  final String reference;
  final String title;
  final String description;
  final String language;
  final String category;
  final String aiCategory;
  final double aiConfidence;
  final String priority;
  final int priorityScore;
  final String priorityReason;
  final String status;
  final String neighbourhood;
  final String address;
  final String? imageUrl;
  final String aiSummary;
  final List<String> tags;
  final List<RecommendationItem> recommendations;
  final String responsibleDepartment;
  final String expectedResponse;
  final int? duplicateOfId;
  final int duplicateCount;
  final int upvotes;
  final int verifications;
  final bool categoryCorrected;
  final String? reporterName;
  final int impactPoints;
  final String createdAt;

  const ReportItem({
    required this.id,
    required this.reference,
    required this.title,
    required this.description,
    required this.language,
    required this.category,
    required this.aiCategory,
    required this.aiConfidence,
    required this.priority,
    required this.priorityScore,
    required this.priorityReason,
    required this.status,
    required this.neighbourhood,
    required this.address,
    required this.imageUrl,
    required this.aiSummary,
    required this.tags,
    required this.recommendations,
    required this.responsibleDepartment,
    required this.expectedResponse,
    required this.duplicateOfId,
    required this.duplicateCount,
    required this.upvotes,
    required this.verifications,
    required this.categoryCorrected,
    required this.reporterName,
    required this.impactPoints,
    required this.createdAt,
  });

  factory ReportItem.fromJson(Map<String, dynamic> json) {
    return ReportItem(
      id: (json['id'] as num?)?.toInt() ?? 0,
      reference: (json['reference'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      language: (json['language'] ?? 'en').toString(),
      category: (json['category'] ?? 'garbage').toString(),
      aiCategory: (json['aiCategory'] ?? 'garbage').toString(),
      aiConfidence: (json['aiConfidence'] as num?)?.toDouble() ?? 0.75,
      priority: (json['priority'] ?? 'medium').toString(),
      priorityScore: (json['priorityScore'] as num?)?.toInt() ?? 50,
      priorityReason: (json['priorityReason'] ?? '').toString(),
      status: (json['status'] ?? 'open').toString(),
      neighbourhood: (json['neighbourhood'] ?? '').toString(),
      address: (json['address'] ?? '').toString(),
      imageUrl: json['imageUrl']?.toString(),
      aiSummary: (json['aiSummary'] ?? '').toString(),
      tags: (json['tags'] as List? ?? const []).map((e) => e.toString()).toList(),
      recommendations: (json['recommendations'] as List? ?? const [])
          .map((e) => RecommendationItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      responsibleDepartment: (json['responsibleDepartment'] ?? '').toString(),
      expectedResponse: (json['expectedResponse'] ?? '').toString(),
      duplicateOfId: (json['duplicateOfId'] as num?)?.toInt(),
      duplicateCount: (json['duplicateCount'] as num?)?.toInt() ?? 0,
      upvotes: (json['upvotes'] as num?)?.toInt() ?? 0,
      verifications: (json['verifications'] as num?)?.toInt() ?? 0,
      categoryCorrected: json['categoryCorrected'] == true,
      reporterName: json['reporterName']?.toString(),
      impactPoints: (json['impactPoints'] as num?)?.toInt() ?? 10,
      createdAt: (json['createdAt'] ?? '').toString(),
    );
  }
}

class ReportUpdateItem {
  final int id;
  final String kind;
  final String note;
  final String actorName;
  final String createdAt;

  const ReportUpdateItem({
    required this.id,
    required this.kind,
    required this.note,
    required this.actorName,
    required this.createdAt,
  });

  factory ReportUpdateItem.fromJson(Map<String, dynamic> json) {
    return ReportUpdateItem(
      id: (json['id'] as num?)?.toInt() ?? 0,
      kind: (json['kind'] ?? 'note').toString(),
      note: (json['note'] ?? '').toString(),
      actorName: (json['actorName'] ?? 'LifeLoop AI').toString(),
      createdAt: (json['createdAt'] ?? '').toString(),
    );
  }
}

class LeaderItem {
  final int id;
  final String name;
  final String handle;
  final String neighbourhood;
  final String role;
  final int points;
  final int reportsCount;
  final int resolvedCount;

  const LeaderItem({
    required this.id,
    required this.name,
    required this.handle,
    required this.neighbourhood,
    required this.role,
    required this.points,
    required this.reportsCount,
    required this.resolvedCount,
  });

  factory LeaderItem.fromJson(Map<String, dynamic> json) {
    return LeaderItem(
      id: (json['id'] as num?)?.toInt() ?? 0,
      name: (json['name'] ?? '').toString(),
      handle: (json['handle'] ?? '').toString(),
      neighbourhood: (json['neighbourhood'] ?? '').toString(),
      role: (json['role'] ?? 'Resident').toString(),
      points: (json['points'] as num?)?.toInt() ?? 0,
      reportsCount: (json['reportsCount'] as num?)?.toInt() ?? 0,
      resolvedCount: (json['resolvedCount'] as num?)?.toInt() ?? 0,
    );
  }
}

class NeighbourhoodStat {
  final String id;
  final String name;
  final double x;
  final double y;
  final int open;
  final int resolved;
  final int total;
  final int highPriority;

  const NeighbourhoodStat({
    required this.id,
    required this.name,
    required this.x,
    required this.y,
    required this.open,
    required this.resolved,
    required this.total,
    required this.highPriority,
  });

  factory NeighbourhoodStat.fromJson(Map<String, dynamic> json) {
    return NeighbourhoodStat(
      id: (json['id'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      x: (json['x'] as num?)?.toDouble() ?? 50,
      y: (json['y'] as num?)?.toDouble() ?? 50,
      open: (json['open'] as num?)?.toInt() ?? 0,
      resolved: (json['resolved'] as num?)?.toInt() ?? 0,
      total: (json['total'] as num?)?.toInt() ?? 0,
      highPriority: (json['highPriority'] as num?)?.toInt() ?? 0,
    );
  }
}

class PlatformStats {
  final int totalReports;
  final int resolved;
  final int inProgress;
  final int open;
  final int highPriority;
  final int duplicatesGrouped;
  final int neighbours;
  final int avgResolutionHours;
  final int impactPoints;
  final int resolutionRate;
  final List<NeighbourhoodStat> byNeighbourhood;

  const PlatformStats({
    required this.totalReports,
    required this.resolved,
    required this.inProgress,
    required this.open,
    required this.highPriority,
    required this.duplicatesGrouped,
    required this.neighbours,
    required this.avgResolutionHours,
    required this.impactPoints,
    required this.resolutionRate,
    required this.byNeighbourhood,
  });

  factory PlatformStats.fromJson(Map<String, dynamic> json) {
    return PlatformStats(
      totalReports: (json['totalReports'] as num?)?.toInt() ?? 0,
      resolved: (json['resolved'] as num?)?.toInt() ?? 0,
      inProgress: (json['inProgress'] as num?)?.toInt() ?? 0,
      open: (json['open'] as num?)?.toInt() ?? 0,
      highPriority: (json['highPriority'] as num?)?.toInt() ?? 0,
      duplicatesGrouped: (json['duplicatesGrouped'] as num?)?.toInt() ?? 0,
      neighbours: (json['neighbours'] as num?)?.toInt() ?? 0,
      avgResolutionHours: (json['avgResolutionHours'] as num?)?.toInt() ?? 0,
      impactPoints: (json['impactPoints'] as num?)?.toInt() ?? 0,
      resolutionRate: (json['resolutionRate'] as num?)?.toInt() ?? 0,
      byNeighbourhood: (json['byNeighbourhood'] as List? ?? const [])
          .map((e) => NeighbourhoodStat.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }
}

class DashboardBundle {
  final List<ReportItem> reports;
  final PlatformStats stats;
  final List<LeaderItem> leaders;
  final LeaderItem? currentUser;

  const DashboardBundle({
    required this.reports,
    required this.stats,
    required this.leaders,
    required this.currentUser,
  });
}

class ReportDetailBundle {
  final ReportItem report;
  final List<ReportUpdateItem> updates;
  final List<ReportItem> related;

  const ReportDetailBundle({
    required this.report,
    required this.updates,
    required this.related,
  });
}
