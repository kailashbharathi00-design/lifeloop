import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/lifeloop_models.dart';

/// Shared backend client for LifeLoop AI.
/// Point [apiBaseUrl] to your running LifeLoop AI Next.js server:
///   flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000   (Android emulator)
///   flutter run --dart-define=API_BASE_URL=http://localhost:3000  (iOS simulator / desktop)
class LifeLoopApiClient {
  final String baseUrl;
  final http.Client _http;
  String? _cookieHeader;

  LifeLoopApiClient({
    String? baseUrl,
    http.Client? httpClient,
  })  : baseUrl = baseUrl ??
            const String.fromEnvironment(
              'API_BASE_URL',
              defaultValue: 'http://10.0.2.2:3000',
            ),
        _http = httpClient ?? http.Client();

  Map<String, String> _headers() {
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (_cookieHeader != null) {
      headers['Cookie'] = _cookieHeader!;
    }
    return headers;
  }

  void _captureCookies(http.Response response) {
    final setCookie = response.headers['set-cookie'];
    if (setCookie != null && setCookie.isNotEmpty) {
      _cookieHeader = setCookie.split(';').first;
    }
  }

  Future<DashboardBundle> fetchDashboard() async {
    final res = await _http.get(
      Uri.parse('$baseUrl/api/reports'),
      headers: _headers(),
    );
    _captureCookies(res);
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Failed to load reports (${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final reports = (data['reports'] as List? ?? const [])
        .map((e) => ReportItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    final leaders = (data['leaders'] as List? ?? const [])
        .map((e) => LeaderItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    final stats = PlatformStats.fromJson(
      Map<String, dynamic>.from((data['stats'] ?? const {}) as Map),
    );
    final currentUser = data['currentUser'] is Map
        ? LeaderItem.fromJson(Map<String, dynamic>.from(data['currentUser'] as Map))
        : null;
    return DashboardBundle(
      reports: reports,
      stats: stats,
      leaders: leaders,
      currentUser: currentUser,
    );
  }

  Future<ReportDetailBundle> fetchReportDetail(int id) async {
    final res = await _http.get(
      Uri.parse('$baseUrl/api/reports/$id'),
      headers: _headers(),
    );
    _captureCookies(res);
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Report not found (${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    return ReportDetailBundle(
      report: ReportItem.fromJson(Map<String, dynamic>.from(data['report'] as Map)),
      updates: (data['updates'] as List? ?? const [])
          .map((e) => ReportUpdateItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      related: (data['related'] as List? ?? const [])
          .map((e) => ReportItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }

  Future<AnalysisResult> analyzeProblem({
    required String title,
    required String description,
    required String language,
    required String neighbourhood,
    String? address,
    String? imageSampleKey,
  }) async {
    final res = await _http.post(
      Uri.parse('$baseUrl/api/analyze'),
      headers: _headers(),
      body: jsonEncode({
        'title': title,
        'description': description,
        'language': language,
        'neighbourhood': neighbourhood,
        'address': address,
        'imageSampleKey': imageSampleKey,
      }),
    );
    _captureCookies(res);
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode < 200 || res.statusCode >= 300 || data['analysis'] == null) {
      throw Exception((data['error'] ?? 'AI analysis failed').toString());
    }
    return AnalysisResult.fromJson(Map<String, dynamic>.from(data['analysis'] as Map));
  }

  Future<int> publishReport({
    required String title,
    required String description,
    required String language,
    required String neighbourhood,
    String? address,
    String? imageSampleKey,
    String? imageUrl,
    required String category,
    required String priority,
    int? duplicateOfId,
  }) async {
    final res = await _http.post(
      Uri.parse('$baseUrl/api/reports'),
      headers: _headers(),
      body: jsonEncode({
        'title': title,
        'description': description,
        'language': language,
        'neighbourhood': neighbourhood,
        'address': address,
        'imageSampleKey': imageSampleKey,
        'imageUrl': imageUrl,
        'category': category,
        'priority': priority,
        'duplicateOfId': duplicateOfId,
      }),
    );
    _captureCookies(res);
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode < 200 || res.statusCode >= 300 || data['id'] == null) {
      throw Exception((data['error'] ?? 'Could not publish report').toString());
    }
    return (data['id'] as num).toInt();
  }

  Future<String> performReportAction(
    int reportId,
    Map<String, dynamic> payload,
  ) async {
    final res = await _http.patch(
      Uri.parse('$baseUrl/api/reports/$reportId'),
      headers: _headers(),
      body: jsonEncode(payload),
    );
    _captureCookies(res);
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception((data['error'] ?? 'Action failed').toString());
    }
    return (data['message'] ?? 'Updated').toString();
  }

  Future<void> switchMember(int userId) async {
    final res = await _http.post(
      Uri.parse('$baseUrl/api/session'),
      headers: _headers(),
      body: jsonEncode({'userId': userId}),
    );
    _captureCookies(res);
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Could not switch member');
    }
  }
}
